# Logistická regrese
* modelování jedonstranného vztahu, jedna vysvětlovaná
* v základní verzi binární logistická regrese - proměnná vysvětlovaná je binární (Y)
* modelujeme její vztah na jedné nebo více proměnných, může být proměnná nominální i kvantitativní
* logistická regrese
* test - interpretace parametrů, jaké mohou být proměnné pro logistickou regresi
* pro binární logres - binární vysvětlovaná
* pro multinomickou - nominální s více než dvě kategoriemi
* jako vysvětlující - tak kategoriální, kvantitativní