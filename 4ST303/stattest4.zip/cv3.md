# Cvičení III.
* test:
    * binomický, chí kvadrát dobré shody, nezávislost dvou proměnných

* Pearsonův chí-kvadrát test nezávislosti v SPSS
    * v prvním sloupci hodnota koeficientu, "approximate significance" - P hodnota kterou srovnáváme s hladinou významnosti
* závislost nominálních proměnných
    * PRE - predikce chyby pro redukci
    * Goodmanovo-Kruskalovo $\lambda$
        * vychází z principu analýzy rozptylu a poměru determinace
        * jednostranné
    * Goodmanovo-Kruskalovo $\tau$
        * z principu analýzy rozptylu a poměru determinace
        * dosadíme do var nominální rozptyl
    * Informační koeficient (koeficient neurčitosti)
        * meziskupinová variabilita je oboustranně stejná
        * jednostranné
* meritorní a demografická - jednostranná závislost 
* příklady - musíme poznat jaké proměnné jsou typově a jestli se jedná o oboustrannou nebo jednostranou závislost!
* závislost ordinálních proměnných
    * Spearmanův koeficient pořadové korelace
        * jestli se se zvýšením jedné proměnné zvýší nebo sníží hodnota jiné proměnné
    * míry založené na počtech konkordantních a diskordantních párů
        * konkordantní - pár buněk, ve kterém se obě proměnné mění stejným směrem
        * diskordantní - 
