v testu z minulého
fisherův test
megn test
poměr šancí