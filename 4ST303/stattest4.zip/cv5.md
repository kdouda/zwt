# Neparametrické testy
* příští test
    * pro závislé výběry, nezávislé výběr, pro binární proměnné -> teoreticky, jaké
* Mannův-Whitneyho test (o shodě rozdělení)
    * jednostranná závislost, ordinální vysvětlovaná proměnná
    * jednostranná závislost pro nezávislé výběry
* Kruskalův-Wallisův test (o shodě rozdělení)
    * nulová hypotéza o shodě rozdělení
* Mediánový test pro K výběrů
    * pro nezávislé výběry
    * vytvoří se pro kategorie nějaké vysvětlující proměnné
    * vytvoří se skupiny na základě vysvětlující proměnné
    * alternativa k ANOVĚ

* závislé výběry
    * znaménkový test
        * dva nezávislé výběry
    * Wilcoxonův párový test
    * Friedmanův test - víc než dva závislé výběry
    * Cochranovo Q - více než dva závislé výběry
